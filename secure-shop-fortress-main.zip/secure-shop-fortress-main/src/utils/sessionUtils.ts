
import { supabase } from "@/integrations/supabase/client";
import { generateCSRFToken, storeCSRFToken } from "./securityUtils";

// Session management functions
export const initializeSecureSession = async () => {
  // Generate and store CSRF token
  const csrfToken = generateCSRFToken();
  storeCSRFToken(csrfToken);
  
  // Get current session from Supabase
  const { data: { session } } = await supabase.auth.getSession();
  
  // If session exists, set up refresh timer
  if (session) {
    // Set up token refresh logic
    setupTokenRefresh(session.expires_at);
  }
  
  return session;
};

// Set up token refresh before expiry
const setupTokenRefresh = (expiresAt: number | undefined) => {
  if (!expiresAt) return;
  
  // Calculate time to refresh (5 minutes before expiry)
  const expiresAtDate = new Date(expiresAt * 1000);
  const refreshTime = expiresAtDate.getTime() - Date.now() - (5 * 60 * 1000);
  
  if (refreshTime <= 0) {
    // Token already expired or about to expire, refresh now
    refreshSession();
  } else {
    // Set timer to refresh before expiry
    setTimeout(() => refreshSession(), refreshTime);
  }
};

// Refresh the session token
const refreshSession = async () => {
  try {
    const { data, error } = await supabase.auth.refreshSession();
    
    if (error) {
      console.error("Failed to refresh session:", error);
      return;
    }
    
    if (data.session) {
      setupTokenRefresh(data.session.expires_at);
    }
  } catch (err) {
    console.error("Error refreshing session:", err);
  }
};

// Securely end a session
export const secureLogout = async () => {
  // Clear CSRF token
  localStorage.removeItem('csrf_token');
  
  // Sign out from Supabase
  return await supabase.auth.signOut();
};

// Check if session is valid and not expired
export const validateSession = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  
  if (!session) {
    return false;
  }
  
  // Check if session is expired
  const expiresAt = session.expires_at ? new Date(session.expires_at * 1000) : null;
  if (expiresAt && expiresAt < new Date()) {
    return false;
  }
  
  return true;
};
