
/**
 * Security utilities for the application
 */

// Content Security Policy (CSP) headers
export const getCSPHeader = (): string => {
  return [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "img-src 'self' data: https://api.qrserver.com",
    "font-src 'self' https://fonts.gstatic.com",
    "connect-src 'self' https://qaxrjyemweevacnytztq.supabase.co",
    "frame-src 'none'",
    "object-src 'none'"
  ].join('; ');
};

// Generate a CSRF token
export const generateCSRFToken = (): string => {
  const array = new Uint8Array(32);
  window.crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};

// Store CSRF token in localStorage (in production, this would be stored in an HttpOnly cookie)
export const storeCSRFToken = (token: string): void => {
  localStorage.setItem('csrf_token', token);
};

// Get stored CSRF token
export const getCSRFToken = (): string | null => {
  return localStorage.getItem('csrf_token');
};

// Sanitize strings to prevent XSS
export const sanitizeInput = (input: string): string => {
  const element = document.createElement('div');
  element.textContent = input;
  return element.innerHTML;
};

// Secure cookie options (for demo purposes)
export const getSecureCookieOptions = () => {
  return {
    httpOnly: true,     // Can't be accessed by JavaScript
    secure: true,       // Only sent over HTTPS
    sameSite: "strict", // Only sent to same site
    maxAge: 3600,       // 1 hour
    path: "/"
  };
};

// Configure client-side security headers (for demo purposes)
export const configureSecurityHeaders = () => {
  // In a real app, these would be set server-side
  if (typeof document !== 'undefined') {
    // Apply CSP using meta tag
    const meta = document.createElement('meta');
    meta.httpEquiv = "Content-Security-Policy";
    meta.content = getCSPHeader();
    document.head.appendChild(meta);
  }
};

// Test for SQL Injection attacks
export const testSQLInjection = (input: string): boolean => {
  // Common SQL injection patterns
  const sqlPatterns = [
    /('|"|;|--|=)/i,                       // Basic SQL special characters
    /(select|insert|update|delete|drop|alter|create|truncate)/i,  // SQL keywords
    /(union\s+select)/i,                  // UNION SELECT attacks
    /(or\s+\d+=\d+|or\s+'.*?'='.*?')/i,   // OR condition attacks
    /(\s+where\s+\d+=\d+|\s+having\s+\d+=\d+)/i, // WHERE/HAVING conditions
  ];
  
  return sqlPatterns.some(pattern => pattern.test(input));
};

// Test for XSS attacks
export const testXSS = (input: string): boolean => {
  // Common XSS patterns
  const xssPatterns = [
    /<script[\s\S]*?>/i,                 // <script> tags
    /(javascript|vbscript|expression):/i, // JavaScript/VBScript protocols
    /<(iframe|embed|object)/i,           // Dangerous HTML elements
    /(onload|onerror|onmouseover|onclick|onmouseout|onfocus)/i, // Event handlers
    /<[^>]*=[^>]*script/i,               // Script attributes
    /<[^>]*=[^>]*(alert|confirm|prompt|eval)/i, // Dangerous JS functions
  ];
  
  return xssPatterns.some(pattern => pattern.test(input));
};

