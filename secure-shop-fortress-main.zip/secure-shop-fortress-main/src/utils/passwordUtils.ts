
import bcrypt from 'bcryptjs';

export const generateSalt = (): string => {
  // Generate a strong salt using bcrypt (cost factor 10)
  return bcrypt.genSaltSync(10);
};

export const hashPassword = async (password: string, salt: string): Promise<string> => {
  // Hash password with bcrypt and salt
  return bcrypt.hashSync(password, salt);
};

export const verifyPassword = (password: string, hashedPassword: string): boolean => {
  // Check if password matches hash
  return bcrypt.compareSync(password, hashedPassword);
};

// Sample demo data for when actual user data isn't available
export const getPasswordDemoData = () => {
  const samplePassword = "P@ssw0rd123!";
  const sampleSalt = "$2a$10$abcdefghijklmnopqrstuv";
  const sampleHashedPassword = bcrypt.hashSync(samplePassword, sampleSalt);
  
  return {
    original_password: samplePassword,
    salt: sampleSalt,
    hashed_password: sampleHashedPassword
  };
};
