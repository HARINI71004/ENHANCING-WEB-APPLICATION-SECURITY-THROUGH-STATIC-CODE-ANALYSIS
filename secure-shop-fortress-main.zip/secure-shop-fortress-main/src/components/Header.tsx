import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ShoppingCart, User, Lock, Shield, Database } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { useCart } from '@/hooks/useCart';
import { supabase } from '@/integrations/supabase/client';
import { secureLogout, validateSession } from '@/utils/sessionUtils';

const Header = () => {
  const { toast } = useToast();
  const { cart } = useCart();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  useEffect(() => {
    // Check if user is logged in
    const checkAuth = async () => {
      const isValid = await validateSession();
      setIsLoggedIn(isValid);
    };

    checkAuth();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setIsLoggedIn(!!session);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const handleLogout = async () => {
    // Use secure logout instead of direct signOut
    await secureLogout();
    
    toast({
      title: "Logged out securely",
      description: "Your session has been terminated",
    });
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link to="/" className="flex items-center">
            <Lock className="h-6 w-6 text-security-600" />
            <span className="text-xl font-bold ml-2">SecureShop</span>
          </Link>
          <Badge variant="outline" className="security-badge animate-pulse-slow">
            <Shield className="h-4 w-4 security-icon" />
            <span>Protected</span>
          </Badge>
        </div>
        
        <nav className="hidden md:flex items-center space-x-4">
          <Link to="/" className="text-gray-700 hover:text-security-600 px-3 py-2 rounded-md">
            Home
          </Link>
          <Link to="/products" className="text-gray-700 hover:text-security-600 px-3 py-2 rounded-md">
            Products
          </Link>
          <Link to="/about" className="text-gray-700 hover:text-security-600 px-3 py-2 rounded-md">
            Security
          </Link>
          <Link to="/security-demo" className="flex items-center text-gray-700 hover:text-security-600 px-3 py-2 rounded-md">
            <Database className="h-4 w-4 mr-1" />
            Password Demo
          </Link>
        </nav>
        
        <div className="flex items-center gap-3">
          <Link to="/cart">
            <Button variant="outline" size="sm" className="relative">
              <ShoppingCart className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-2 -right-2 bg-security-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Button>
          </Link>
          
          {isLoggedIn ? (
            <div className="flex items-center gap-2">
              <Link to="/account">
                <Button variant="ghost" size="sm">
                  <User className="h-5 w-5 mr-2" />
                  Account
                </Button>
              </Link>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
              >
                Logout
              </Button>
            </div>
          ) : (
            <Link to="/login">
              <Button variant="default" size="sm" className="bg-security-600 hover:bg-security-700">
                <User className="h-5 w-5 mr-2" />
                Login
              </Button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
