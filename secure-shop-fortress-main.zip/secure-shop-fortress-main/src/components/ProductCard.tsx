
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { ShieldCheck, ShoppingCart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Product, useCart } from '@/hooks/useCart';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { toast } = useToast();
  const { addToCart } = useCart();

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  return (
    <Card className="product-card overflow-hidden">
      <div className="aspect-video relative overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform hover:scale-105"
        />
        <Badge className="absolute top-2 right-2 bg-security-600">
          <ShieldCheck className="h-3 w-3 mr-1" />
          Secured
        </Badge>
      </div>
      <CardHeader className="p-4">
        <CardTitle className="text-xl">{product.name}</CardTitle>
        <CardDescription>{product.description.substring(0, 100)}...</CardDescription>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <p className="text-2xl font-bold">${product.price.toFixed(2)}</p>
      </CardContent>
      <CardFooter className="p-4 flex justify-between">
        <Link to={`/products/${product.id}`}>
          <Button variant="outline">View Details</Button>
        </Link>
        <Button 
          onClick={handleAddToCart}
          className="bg-security-600 hover:bg-security-700"
        >
          <ShoppingCart className="h-4 w-4 mr-2" />
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ProductCard;
