
import { Link } from 'react-router-dom';
import { ShieldCheck, Lock, Shield } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

const Footer = () => {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 py-8 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Lock className="h-5 w-5 mr-2 text-security-600" />
              SecureShop
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Our e-commerce platform implements industry-leading security measures to keep your data safe.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Security Features</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2 text-security-600" />
                <span>Password Hashing (bcrypt)</span>
              </li>
              <li className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2 text-security-600" />
                <span>Two-Factor Authentication</span>
              </li>
              <li className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2 text-security-600" />
                <span>SQL Injection Protection</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">More Protections</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2 text-security-600" />
                <span>XSS Protection</span>
              </li>
              <li className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2 text-security-600" />
                <span>CSRF Protection</span>
              </li>
              <li className="flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2 text-security-600" />
                <span>Secure Cookies</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="text-gray-600 hover:text-security-600">Home</Link>
              </li>
              <li>
                <Link to="/products" className="text-gray-600 hover:text-security-600">Products</Link>
              </li>
              <li>
                <Link to="/login" className="text-gray-600 hover:text-security-600">Login</Link>
              </li>
              <li>
                <Link to="/register" className="text-gray-600 hover:text-security-600">Register</Link>
              </li>
            </ul>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm text-gray-600">© {new Date().getFullYear()} SecureShop. All rights reserved.</p>
          <div className="flex items-center gap-2 mt-4 md:mt-0">
            <span className="text-xs text-gray-600">Protected by</span>
            <div className="flex items-center security-badge">
              <Shield className="h-4 w-4 security-icon" />
              <span>Enterprise Security</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
