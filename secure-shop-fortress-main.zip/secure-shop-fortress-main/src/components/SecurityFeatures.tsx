
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Shield, Lock, Key } from 'lucide-react';

const securityFeatures = [
  {
    title: 'Password Security',
    description: 'Passwords are securely hashed using bcrypt with proper salt rounds.',
    icon: <Key className="h-6 w-6 text-security-600" />,
  },
  {
    title: 'Two-Factor Authentication',
    description: 'Additional layer of security requiring a second verification step.',
    icon: <Shield className="h-6 w-6 text-security-600" />,
  },
  {
    title: 'SQL Injection Protection',
    description: 'Prepared statements and input validation to prevent database attacks.',
    icon: <Shield className="h-6 w-6 text-security-600" />,
  },
  {
    title: 'XSS Protection',
    description: 'Content sanitization to prevent cross-site scripting attacks.',
    icon: <Shield className="h-6 w-6 text-security-600" />,
  },
  {
    title: 'CSRF Protection',
    description: 'Anti-forgery tokens to prevent cross-site request forgery.',
    icon: <Shield className="h-6 w-6 text-security-600" />,
  },
  {
    title: 'Secure Cookies',
    description: 'HTTPOnly, Secure, and SameSite flags protect cookie data.',
    icon: <Lock className="h-6 w-6 text-security-600" />,
  },
];

const SecurityFeatures = () => {
  return (
    <section className="py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Advanced Security Features</h2>
          <p className="text-gray-600">
            Our platform implements multiple layers of security to protect your data and transactions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {securityFeatures.map((feature, index) => (
            <Card key={index} className="border border-gray-200 hover:border-security-300 transition-colors">
              <CardHeader className="flex flex-row items-center gap-4 pb-2">
                <div className="bg-security-100 p-3 rounded-full">{feature.icon}</div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SecurityFeatures;
