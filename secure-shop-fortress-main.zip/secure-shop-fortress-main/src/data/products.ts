
import { Product } from '@/hooks/useCart';

const products: Product[] = [
  {
    id: 1,
    name: 'Secure Laptop Pro',
    description: 'High-performance laptop with built-in security features including hardware encryption, fingerprint reader, and secure boot.',
    price: 999.99,
    image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
    category: 'electronics'
  },
  {
    id: 2,
    name: 'Security Token Plus',
    description: 'Two-factor authentication hardware token for maximum account security with military-grade encryption.',
    price: 49.99,
    image: 'https://images.unsplash.com/photo-1610513320995-1ad4bbf25e55?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
    category: 'accessories'
  },
  {
    id: 3,
    name: 'Encrypted External Drive',
    description: '1TB external hard drive with hardware encryption and secure password protection for sensitive data.',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1531492746076-161ca9bcad58?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
    category: 'storage'
  }
];

export default products;
