
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { User, Lock, Shield, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { sanitizeInput } from "@/utils/securityUtils";
import { initializeSecureSession } from "@/utils/sessionUtils";
import { verifyPassword } from "@/utils/passwordUtils";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loginAttempts, setLoginAttempts] = useState(0);
  const { toast } = useToast();
  const navigate = useNavigate();

  // Initialize security on component mount
  useEffect(() => {
    const initSecurity = async () => {
      const session = await initializeSecureSession();
      if (session) {
        navigate("/");
      }
    };
    
    initSecurity();
  }, [navigate]);

  // Rate limiting for failed login attempts
  useEffect(() => {
    if (loginAttempts >= 5) {
      const timeout = setTimeout(() => {
        setLoginAttempts(0);
      }, 60000); // Reset after 1 minute
      
      return () => clearTimeout(timeout);
    }
  }, [loginAttempts]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    // Check rate limiting
    if (loginAttempts >= 5) {
      setError("Too many failed attempts. Please try again later.");
      setIsSubmitting(false);
      return;
    }

    try {
      // Sanitize inputs to prevent XSS
      const sanitizedEmail = sanitizeInput(email);
      
      // Authenticate with Supabase
      const { data, error } = await supabase.auth.signInWithPassword({
        email: sanitizedEmail,
        password,
      });

      if (error) {
        console.error("Login error:", error);
        setError(error.message);
        setLoginAttempts(prev => prev + 1);
        return;
      }

      if (!data.user || !data.session) {
        setError("Login failed. Please try again.");
        setLoginAttempts(prev => prev + 1);
        return;
      }

      // Create session log
      const userAgent = navigator.userAgent;
      // In a real app, we'd use a service to get the IP address
      const ipAddress = "127.0.0.1"; // Placeholder

      // Call the log_session function
      const { data: sessionData, error: sessionError } = await supabase.rpc(
        'log_session',
        { 
          user_id: data.user.id, 
          ip: ipAddress, 
          agent: userAgent 
        }
      );

      if (sessionError) {
        console.error("Error logging session:", sessionError);
      }

      toast({
        title: "Login successful",
        description: "Welcome back! You are now logged in.",
      });

      // Check if 2FA is required
      const { data: securityData, error: securityError } = await supabase
        .from("user_security")
        .select("two_factor_enabled, two_factor_verified")
        .eq("id", data.user.id)
        .single();

      if (!securityError && securityData && securityData.two_factor_enabled && securityData.two_factor_verified) {
        // In a real app, we would implement 2FA verification here
        // For this demo, we'll just show a toast
        toast({
          title: "Two-factor authentication",
          description: "In a production app, you'd be asked for your 2FA code now.",
        });
      }

      navigate("/"); // Redirect to home page
    } catch (err) {
      console.error("Login error:", err);
      setError("An unexpected error occurred. Please try again.");
      setLoginAttempts(prev => prev + 1);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle email input with sanitization
  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
  };

  // Handle password input
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
  };

  return (
    <div className="container mx-auto px-4 py-16 flex justify-center">
      <Card className="w-full max-w-md shadow-lg border-security-200">
        <CardHeader className="space-y-1">
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl">Login</CardTitle>
            <Badge variant="outline" className="security-badge">
              <Shield className="h-4 w-4 security-icon" />
              <span>Secured</span>
            </Badge>
          </div>
          <CardDescription>
            Enter your email and password to access your account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  className="pl-10"
                  value={email}
                  onChange={handleEmailChange}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="password">Password</Label>
                <Link
                  to="/forgot-password"
                  className="text-xs text-security-600 hover:text-security-700"
                >
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <Input
                  id="password"
                  type="password"
                  className="pl-10"
                  value={password}
                  onChange={handlePasswordChange}
                  required
                />
              </div>
            </div>
            <Button
              type="submit"
              className="w-full bg-security-600 hover:bg-security-700"
              disabled={isSubmitting || loginAttempts >= 5}
            >
              {isSubmitting ? "Logging in..." : loginAttempts >= 5 ? "Too many attempts" : "Login"}
            </Button>
          </form>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-white px-2 text-gray-500">Or</span>
            </div>
          </div>

          <Button variant="outline" className="w-full">
            Continue with Google
          </Button>
        </CardContent>
        <CardFooter>
          <p className="text-center text-sm text-gray-600 w-full">
            Don't have an account?{" "}
            <Link
              to="/register"
              className="text-security-600 hover:text-security-700 font-medium"
            >
              Create an account
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Login;
