
import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { ShieldCheck, ShoppingCart, ArrowLeft } from 'lucide-react';
import products from '@/data/products';
import { useCart } from '@/hooks/useCart';

const ProductDetail = () => {
  const { productId } = useParams<{ productId: string }>();
  const product = products.find((p) => p.id === Number(productId));
  const [quantity, setQuantity] = useState(1);
  const { toast } = useToast();
  const { addToCart } = useCart();
  
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold mb-4">Product Not Found</h1>
        <p className="mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Link to="/products">
          <Button>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Products
          </Button>
        </Link>
      </div>
    );
  }
  
  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast({
      title: "Added to cart",
      description: `${quantity} ${quantity === 1 ? 'unit' : 'units'} of ${product.name} added to your cart.`,
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <Link to="/products" className="inline-flex items-center text-security-600 hover:text-security-700 mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Products
      </Link>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="relative">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full rounded-lg shadow-md"
          />
          <Badge className="absolute top-4 right-4 bg-security-600">
            <ShieldCheck className="h-4 w-4 mr-1" />
            Secured Product
          </Badge>
        </div>
        
        <div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
          <p className="text-3xl font-bold text-security-600 mb-6">${product.price.toFixed(2)}</p>
          
          <div className="prose max-w-none mb-6">
            <p>{product.description}</p>
          </div>
          
          <Card className="mb-6 border-security-200">
            <CardContent className="p-4">
              <div className="flex items-center mb-2">
                <ShieldCheck className="h-5 w-5 text-security-600 mr-2" />
                <span className="font-semibold">Secure Transaction</span>
              </div>
              <p className="text-sm text-gray-600">
                Your payment information is processed securely. We do not store or have access to your payment details.
              </p>
            </CardContent>
          </Card>
          
          <div className="flex items-center gap-4 mb-6">
            <label htmlFor="quantity" className="font-medium">Quantity:</label>
            <div className="flex items-center">
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                -
              </Button>
              <span className="w-12 text-center">{quantity}</span>
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => setQuantity(quantity + 1)}
              >
                +
              </Button>
            </div>
          </div>
          
          <Button 
            onClick={handleAddToCart} 
            size="lg" 
            className="w-full bg-security-600 hover:bg-security-700"
          >
            <ShoppingCart className="mr-2 h-5 w-5" />
            Add to Cart
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
