
import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { Shield, Lock, AlertCircle, Terminal, Database, CheckCircle, XCircle, Bug, Code } from "lucide-react";
import { 
  getCSPHeader, 
  generateCSRFToken, 
  configureSecurityHeaders, 
  sanitizeInput,
  testSQLInjection,
  testXSS 
} from "@/utils/securityUtils";
import { initializeSecureSession } from "@/utils/sessionUtils";
import { toast } from "@/components/ui/use-toast";
import { getPasswordDemoData } from "@/utils/passwordUtils";

// Test data for demo
const sqlInjectionTest = "SELECT * FROM users WHERE username = 'admin' OR 1=1;";
const xssTest = "<script>alert('XSS')</script>";

const SecurityDemo = () => {
  const [user, setUser] = useState<any>(null);
  const [passwordDemo, setPasswordDemo] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [csrfToken, setCsrfToken] = useState<string | null>(null);
  const [attackInput, setAttackInput] = useState("");
  const [attackResult, setAttackResult] = useState<{type: string, detected: boolean, sanitized: string} | null>(null);
  const [useRealData, setUseRealData] = useState(true);

  useEffect(() => {
    // Initialize security configurations
    configureSecurityHeaders();
    loadSecurityData();
    
    // Generate a new CSRF token for this page
    const token = generateCSRFToken();
    setCsrfToken(token);
    
    // Initialize secure session
    initializeSecureSession();
  }, []);

  const loadSecurityData = async () => {
    try {
      setIsLoading(true);
      
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      
      if (user) {
        console.log("Current user ID:", user.id);
        
        // Fetch password demo data
        const { data: passwordData, error: passwordError } = await supabase
          .from('password_demo')
          .select('*')
          .eq('user_id', user.id)
          .limit(1);
          
        if (passwordError) {
          console.error("Error fetching password demo data:", passwordError);
          // Fall back to demo data if there's an error
          setPasswordDemo(getPasswordDemoData());
          setUseRealData(false);
        } else if (passwordData && passwordData.length > 0) {
          console.log("Password demo data found:", passwordData[0]);
          setPasswordDemo(passwordData[0]);
          setUseRealData(true);
        } else {
          console.log("No password demo data found for user", user.id);
          // Fall back to demo data if no data is found
          setPasswordDemo(getPasswordDemoData());
          setUseRealData(false);
        }
      } else {
        console.log("No authenticated user found");
        // Fall back to demo data if no user is found
        setPasswordDemo(getPasswordDemoData());
        setUseRealData(false);
      }
    } catch (err) {
      console.error("Error loading security data:", err);
      // Fall back to demo data in case of any error
      setPasswordDemo(getPasswordDemoData());
      setUseRealData(false);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Handle attack simulation
  const simulateAttack = (type: string) => {
    let detected = false;
    let sanitizedInput = "";
    
    switch (type) {
      case "sql":
        detected = testSQLInjection(attackInput);
        sanitizedInput = attackInput.replace(/['";=]|--/g, "");
        setAttackResult({ type: "SQL Injection", detected, sanitized: sanitizedInput });
        break;
      case "xss":
        detected = testXSS(attackInput);
        sanitizedInput = sanitizeInput(attackInput);
        setAttackResult({ type: "XSS Attack", detected, sanitized: sanitizedInput });
        break;
      case "csrf":
        // Simulate a CSRF attack (missing or invalid token)
        const providedToken = attackInput.trim();
        detected = providedToken !== csrfToken;
        setAttackResult({ type: "CSRF Attack", detected, sanitized: "Token validation failed" });
        break;
    }
    
    if (detected) {
      toast({
        title: "Attack Detected!",
        description: `The ${type === "sql" ? "SQL injection" : type === "xss" ? "XSS" : "CSRF"} attack was detected and blocked.`,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold">Security Features Demo</h1>
            <p className="text-gray-600 mt-1">
              Demonstration of implemented security features
            </p>
          </div>
          <Badge variant="outline" className="security-badge px-3 py-1">
            <Shield className="h-5 w-5 security-icon mr-2" />
            <span>Security Features</span>
          </Badge>
        </div>

        {!user && useRealData ? (
          <Alert className="mb-6">
            <AlertCircle className="h-4 w-4 text-amber-500" />
            <AlertDescription>
              Please log in to see all security features demonstrations.
            </AlertDescription>
          </Alert>
        ) : null}

        <Tabs defaultValue="password" className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
            <TabsTrigger value="password">Password Security</TabsTrigger>
            <TabsTrigger value="injection">Injection Protection</TabsTrigger>
            <TabsTrigger value="session">Session Security</TabsTrigger>
            <TabsTrigger value="other">Other Features</TabsTrigger>
            <TabsTrigger value="attacks">Attack Simulation</TabsTrigger>
          </TabsList>
          
          <TabsContent value="password" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Lock className="h-5 w-5 mr-2 text-security-600" />
                  Password Hashing Demo
                </CardTitle>
                <CardDescription>
                  Demonstration of bcrypt password hashing with salt
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="py-4 text-center">Loading password data...</div>
                ) : passwordDemo ? (
                  <div className="space-y-4">
                    <Alert variant="destructive" className={`bg-amber-50 border-amber-200 ${!useRealData ? 'bg-blue-50 border-blue-200' : ''}`}>
                      <AlertCircle className={`h-4 w-4 ${!useRealData ? 'text-blue-500' : 'text-amber-500'}`} />
                      <AlertDescription className={`${!useRealData ? 'text-blue-700' : 'text-amber-700'}`}>
                        {useRealData ? (
                          "This is for demonstration purposes only. In a real application, original passwords would never be stored or displayed."
                        ) : (
                          "Using placeholder demo data. To see your actual password data, please register an account or log in."
                        )}
                      </AlertDescription>
                    </Alert>
                    
                    <div className="grid gap-4">
                      <div className="border rounded-md p-4">
                        <h3 className="font-medium mb-1">Original Password</h3>
                        <div className="bg-gray-50 p-3 rounded font-mono text-sm overflow-x-auto">
                          {passwordDemo.original_password}
                        </div>
                      </div>
                      
                      <div className="border rounded-md p-4">
                        <h3 className="font-medium mb-1">Salt</h3>
                        <div className="bg-gray-50 p-3 rounded font-mono text-sm overflow-x-auto">
                          {passwordDemo.salt}
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          The salt is a random string that is combined with the password before hashing.
                          This prevents rainbow table attacks.
                        </p>
                      </div>
                      
                      <div className="border rounded-md p-4">
                        <h3 className="font-medium mb-1">Hashed Password (bcrypt)</h3>
                        <div className="bg-gray-50 p-3 rounded font-mono text-sm overflow-x-auto break-all">
                          {passwordDemo.hashed_password}
                        </div>
                        <p className="text-xs text-gray-500 mt-2">
                          The bcrypt hash is stored in the database. The original password cannot be 
                          recovered from this hash.
                        </p>
                      </div>

                      {!useRealData && (
                        <Button 
                          variant="outline" 
                          className="mt-4"
                          onClick={() => loadSecurityData()}
                        >
                          Refresh Data
                        </Button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p>No password data found. Please register an account to see the demo.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="injection" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Database className="h-5 w-5 mr-2 text-security-600" />
                  SQL Injection & XSS Protection
                </CardTitle>
                <CardDescription>
                  Demonstration of protection against common injection attacks
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-medium">SQL Injection Protection</h3>
                  <div className="border rounded-md p-4">
                    <p className="mb-2">Malicious SQL injection attempt:</p>
                    <div className="bg-gray-50 p-3 rounded font-mono text-sm overflow-x-auto mb-3">
                      {sqlInjectionTest}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Badge className={testSQLInjection(sqlInjectionTest) ? "bg-green-100 text-green-800 border-green-200" : "bg-red-100 text-red-800 border-red-200"}>
                        {testSQLInjection(sqlInjectionTest) ? (
                          <CheckCircle className="h-3 w-3 mr-1" />
                        ) : (
                          <XCircle className="h-3 w-3 mr-1" />
                        )}
                        {testSQLInjection(sqlInjectionTest) ? "Detected & Prevented" : "Not Protected"}
                      </Badge>
                      
                      <p className="text-sm text-gray-600">
                        All database queries use parameterized statements via Supabase
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="font-medium">XSS Protection</h3>
                  <div className="border rounded-md p-4">
                    <p className="mb-2">Malicious XSS attempt:</p>
                    <div className="bg-gray-50 p-3 rounded font-mono text-sm overflow-x-auto mb-3">
                      {xssTest.replace(/</g, "&lt;").replace(/>/g, "&gt;")}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Badge className={testXSS(xssTest) ? "bg-green-100 text-green-800 border-green-200" : "bg-red-100 text-red-800 border-red-200"}>
                        {testXSS(xssTest) ? (
                          <CheckCircle className="h-3 w-3 mr-1" />
                        ) : (
                          <XCircle className="h-3 w-3 mr-1" />
                        )}
                        {testXSS(xssTest) ? "Detected & Prevented" : "Not Protected"}
                      </Badge>
                      
                      <p className="text-sm text-gray-600">
                        Input sanitization prevents script injection
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">CSRF Protection</h3>
                  <div className="border rounded-md p-4">
                    <p className="mb-2">Generated CSRF Token:</p>
                    <div className="bg-gray-50 p-3 rounded font-mono text-sm overflow-x-auto mb-3">
                      {csrfToken || "No token generated"}
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-2">
                      CSRF tokens are unique per session and required for all state-changing operations
                    </p>
                    
                    <Button 
                      onClick={() => setCsrfToken(generateCSRFToken())}
                      variant="outline"
                      className="text-xs"
                    >
                      Generate New Token
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="session" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2 text-security-600" />
                  Session Security
                </CardTitle>
                <CardDescription>
                  Features to secure user sessions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <h3 className="font-medium">Secure Session Configuration</h3>
                  <div className="border rounded-md p-4 space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Auto Token Refresh</span>
                      <Badge className="bg-green-100 text-green-800 border-green-200">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Enabled
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Session Expiration</span>
                      <Badge className="bg-green-100 text-green-800 border-green-200">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        24 Hours
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Session Activity Logging</span>
                      <Badge className="bg-green-100 text-green-800 border-green-200">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Enabled
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Secure Session Storage</span>
                      <Badge className="bg-green-100 text-green-800 border-green-200">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Enabled
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-gray-600 mt-2">
                      Sessions are stored securely and refreshed automatically before expiration
                    </p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="font-medium">Cookie Security</h3>
                  <div className="border rounded-md p-4">
                    <h4 className="text-sm font-medium mb-3">Secure Cookie Options</h4>
                    
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="bg-gray-50 p-2 rounded">
                        <span className="font-mono">HttpOnly:</span> <span className="text-green-600">true</span>
                      </div>
                      <div className="bg-gray-50 p-2 rounded">
                        <span className="font-mono">Secure:</span> <span className="text-green-600">true</span>
                      </div>
                      <div className="bg-gray-50 p-2 rounded">
                        <span className="font-mono">SameSite:</span> <span className="text-green-600">strict</span>
                      </div>
                      <div className="bg-gray-50 p-2 rounded">
                        <span className="font-mono">Path:</span> <span className="text-gray-600">/</span>
                      </div>
                    </div>
                    
                    <p className="text-xs text-gray-500 mt-3">
                      HttpOnly cookies cannot be accessed by JavaScript, preventing XSS attacks from stealing session data.
                      Secure cookies are only transmitted over HTTPS connections.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="other" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Terminal className="h-5 w-5 mr-2 text-security-600" />
                  Content Security Policy
                </CardTitle>
                <CardDescription>
                  CSP reduces the risk of XSS attacks
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="border rounded-md p-4">
                  <h3 className="text-sm font-medium mb-2">Active CSP Header</h3>
                  <div className="bg-gray-50 p-3 rounded font-mono text-xs overflow-x-auto break-all">
                    {getCSPHeader()}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Content Security Policy restricts sources of executable scripts, 
                    styles, and other resources
                  </p>
                </div>
                
                <div className="mt-4 grid gap-4">
                  <div className="border rounded-md p-4">
                    <h3 className="text-sm font-medium mb-2">Additional Security Headers</h3>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-center">
                        <CheckCircle className="h-3 w-3 text-green-600 mr-2" />
                        <span className="font-mono text-xs mr-2">X-XSS-Protection: 1; mode=block</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-3 w-3 text-green-600 mr-2" />
                        <span className="font-mono text-xs mr-2">X-Frame-Options: DENY</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-3 w-3 text-green-600 mr-2" />
                        <span className="font-mono text-xs mr-2">X-Content-Type-Options: nosniff</span>
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-3 w-3 text-green-600 mr-2" />
                        <span className="font-mono text-xs mr-2">Referrer-Policy: strict-origin</span>
                      </li>
                    </ul>
                    <p className="text-xs text-gray-500 mt-2">
                      These headers provide additional layers of protection against common web vulnerabilities
                    </p>
                  </div>
                  
                  <div className="border rounded-md p-4">
                    <h3 className="text-sm font-medium mb-2">Two-Factor Authentication</h3>
                    <Badge className="bg-amber-100 text-amber-800 border-amber-200 mb-2">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Implemented (Demo Mode)
                    </Badge>
                    <p className="text-xs text-gray-600">
                      2FA adds an additional layer of security beyond passwords.
                      You can enable it in your account settings.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="attacks" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bug className="h-5 w-5 mr-2 text-security-600" />
                  Attack Simulation
                </CardTitle>
                <CardDescription>
                  Test how the application handles and blocks various attacks
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert variant="destructive" className="bg-amber-50 border-amber-200">
                  <AlertCircle className="h-4 w-4 text-amber-500" />
                  <AlertDescription className="text-amber-700">
                    This is for demonstration purposes only. In a real application, these attacks would be blocked by security measures.
                  </AlertDescription>
                </Alert>
                
                <div className="space-y-4">
                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-3">Input malicious code to test attack prevention</h3>
                    <div className="space-y-3">
                      <div>
                        <Input 
                          value={attackInput}
                          onChange={(e) => setAttackInput(e.target.value)}
                          placeholder="Enter attack vector (e.g. <script>alert('xss')</script>)"
                          className="font-mono"
                        />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Button 
                          variant="outline" 
                          className="bg-security-50 text-security-700 hover:bg-security-100" 
                          onClick={() => simulateAttack("sql")}
                        >
                          <Database className="h-4 w-4 mr-2" />
                          Test SQL Injection
                        </Button>
                        <Button 
                          variant="outline" 
                          className="bg-security-50 text-security-700 hover:bg-security-100" 
                          onClick={() => simulateAttack("xss")}
                        >
                          <Code className="h-4 w-4 mr-2" />
                          Test XSS Attack
                        </Button>
                        <Button 
                          variant="outline" 
                          className="bg-security-50 text-security-700 hover:bg-security-100" 
                          onClick={() => simulateAttack("csrf")}
                        >
                          <Shield className="h-4 w-4 mr-2" />
                          Test CSRF Attack
                        </Button>
                      </div>
                    </div>
                  </div>
                  
                  {attackResult && (
                    <div className="border rounded-md p-4 bg-gray-50">
                      <div className="flex justify-between items-center mb-3">
                        <h3 className="font-medium">Attack Detection Results</h3>
                        <Badge className={attackResult.detected ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                          {attackResult.detected ? (
                            <><CheckCircle className="h-3 w-3 mr-1" /> Detected & Blocked</>
                          ) : (
                            <><XCircle className="h-3 w-3 mr-1" /> Not Detected</>
                          )}
                        </Badge>
                      </div>
                      
                      <div className="space-y-3">
                        <div>
                          <p className="text-sm font-medium">Attack Type</p>
                          <div className="bg-white p-2 rounded border mt-1">
                            {attackResult.type}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium">Original Input</p>
                          <div className="bg-white p-2 rounded border mt-1 font-mono text-sm break-all">
                            {attackInput.replace(/</g, "&lt;").replace(/>/g, "&gt;")}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium">Sanitized Output</p>
                          <div className="bg-white p-2 rounded border mt-1 font-mono text-sm break-all">
                            {attackResult.sanitized.replace(/</g, "&lt;").replace(/>/g, "&gt;")}
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-4">
                        <Alert variant="destructive" className="bg-green-50 border-green-200">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <AlertDescription className="text-green-800">
                            {attackResult.detected ? 
                              "The attack was successfully detected and blocked by the application's security measures." :
                              "This input was determined to be safe."
                            }
                          </AlertDescription>
                        </Alert>
                      </div>
                    </div>
                  )}
                  
                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-3">How Our Protection Works</h3>
                    <div className="space-y-3">
                      <div>
                        <h4 className="text-sm font-medium">SQL Injection Protection</h4>
                        <p className="text-sm text-gray-600 mt-1">
                          Our application uses parameterized queries and input validation to prevent SQL injection attacks.
                          Special characters and SQL commands are sanitized before being used in database operations.
                        </p>
                        <div className="bg-gray-100 p-2 rounded mt-2 font-mono text-xs">
                          const sanitized = input.replace(/['";=]|--/g, "");
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium">XSS Protection</h4>
                        <p className="text-sm text-gray-600 mt-1">
                          Input sanitization removes potentially dangerous HTML and JavaScript code.
                          Content Security Policy (CSP) headers provide additional protection.
                        </p>
                        <div className="bg-gray-100 p-2 rounded mt-2 font-mono text-xs">
                          const sanitized = element.textContent = input; // Removes HTML
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-sm font-medium">CSRF Protection</h4>
                        <p className="text-sm text-gray-600 mt-1">
                          Unique tokens are generated for each session and validated for all state-changing operations.
                          This prevents cross-site request forgery attacks.
                        </p>
                        <div className="bg-gray-100 p-2 rounded mt-2 font-mono text-xs">
                          window.crypto.getRandomValues(array); // Generate secure random token
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SecurityDemo;
