
import { Button } from '@/components/ui/button';
import { ShieldCheck, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';
import ProductCard from '@/components/ProductCard';
import SecurityFeatures from '@/components/SecurityFeatures';
import products from '@/data/products';

const Home = () => {
  // Display only first 3 products on homepage
  const featuredProducts = products.slice(0, 3);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-security-800 to-security-600 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">Secure Shopping Experience</h1>
            <p className="text-xl mb-8">
              Shop with confidence using our security-focused e-commerce platform. Your data and transactions are protected by industry-leading security measures.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/products">
                <Button size="lg" className="bg-white text-security-800 hover:bg-gray-100">
                  <ShoppingBag className="mr-2 h-5 w-5" />
                  Shop Now
                </Button>
              </Link>
              <Link to="/about">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  <ShieldCheck className="mr-2 h-5 w-5" />
                  Learn About Security
                </Button>
              </Link>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 right-0 opacity-20 pointer-events-none">
          <ShieldCheck className="h-64 w-64" />
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Featured Products</h2>
            <Link to="/products">
              <Button variant="link" className="text-security-600 hover:text-security-700">
                View All Products
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Security Features Section */}
      <SecurityFeatures />

      {/* Trust Indicators */}
      <section className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Why Choose SecureShop?</h2>
            <p className="text-xl text-gray-600 mb-8">
              We prioritize security without compromising on user experience. Our platform is designed to keep your data safe while providing a seamless shopping experience.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <div className="security-badge">
                <ShieldCheck className="h-4 w-4 security-icon" />
                <span>Encrypted Data</span>
              </div>
              <div className="security-badge">
                <ShieldCheck className="h-4 w-4 security-icon" />
                <span>Secure Transactions</span>
              </div>
              <div className="security-badge">
                <ShieldCheck className="h-4 w-4 security-icon" />
                <span>Protected Information</span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
