
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, User, Lock, LogOut, Key, AlertCircle, History } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Account = () => {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [userSecurity, setUserSecurity] = useState<any>(null);
  const [sessionLogs, setSessionLogs] = useState<any[]>([]);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (!session) {
          toast({
            title: "Authentication required",
            description: "Please log in to access your account",
            variant: "destructive",
          });
          navigate("/login");
          return;
        }
        
        setUser(session.user);
        
        // Fetch security info
        const { data: securityData, error: securityError } = await supabase
          .from("user_security")
          .select("*")
          .eq("id", session.user.id)
          .single();
          
        if (securityError) {
          console.error("Error fetching security data:", securityError);
        } else {
          setUserSecurity(securityData);
        }
        
        // Fetch session logs
        const { data: logsData, error: logsError } = await supabase
          .from("session_logs")
          .select("*")
          .eq("user_id", session.user.id)
          .order("created_at", { ascending: false })
          .limit(5);
          
        if (logsError) {
          console.error("Error fetching session logs:", logsError);
        } else {
          setSessionLogs(logsData || []);
        }
        
        setLoading(false);
      } catch (err) {
        console.error("Error checking auth status:", err);
        setError("Failed to load account information");
        setLoading(false);
      }
    };

    checkAuthStatus();
  }, [navigate, toast]);

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Logged out successfully",
        description: "You have been securely logged out",
      });
      navigate("/login");
    } catch (err) {
      console.error("Error signing out:", err);
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16 flex justify-center">
        <p>Loading account information...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">My Account</h1>
          <Button variant="outline" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>

        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-3 w-full">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
            <TabsTrigger value="activity" className="hidden md:block">Activity</TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>
                  View and manage your account details
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-500">Email</label>
                  <p className="text-lg font-medium">{user?.email}</p>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-500">User ID</label>
                  <p className="text-sm text-gray-600 font-mono">{user?.id}</p>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-500">Account Created</label>
                  <p className="text-sm">
                    {user?.created_at ? new Date(user.created_at).toLocaleString() : 'N/A'}
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline">Edit Profile</Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          <TabsContent value="security" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Security Settings</CardTitle>
                  <Badge variant="outline" className="security-badge">
                    <Shield className="h-4 w-4 security-icon" />
                    <span>Protected</span>
                  </Badge>
                </div>
                <CardDescription>
                  Manage your account security and authentication options
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid gap-6">
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-4">
                      <div className="bg-security-100 p-2.5 rounded-full">
                        <Key className="h-5 w-5 text-security-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">Two-Factor Authentication</h3>
                        <p className="text-sm text-gray-500">
                          {userSecurity?.two_factor_enabled && userSecurity?.two_factor_verified 
                            ? 'Enabled' 
                            : 'Not enabled'}
                        </p>
                      </div>
                    </div>
                    <Link to="/two-factor">
                      <Button variant="outline">
                        {userSecurity?.two_factor_enabled && userSecurity?.two_factor_verified
                          ? 'Manage'
                          : 'Set up'}
                      </Button>
                    </Link>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-4">
                      <div className="bg-security-100 p-2.5 rounded-full">
                        <Lock className="h-5 w-5 text-security-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">Change Password</h3>
                        <p className="text-sm text-gray-500">
                          Last changed: {userSecurity?.updated_at 
                            ? new Date(userSecurity.updated_at).toLocaleDateString() 
                            : 'Never'}
                        </p>
                      </div>
                    </div>
                    <Button variant="outline">Update</Button>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-4">
                      <div className="bg-security-100 p-2.5 rounded-full">
                        <User className="h-5 w-5 text-security-600" />
                      </div>
                      <div>
                        <h3 className="font-medium">Account Recovery</h3>
                        <p className="text-sm text-gray-500">
                          Set up recovery options for your account
                        </p>
                      </div>
                    </div>
                    <Button variant="outline">Configure</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="activity" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>
                  View your recent account activity and login history
                </CardDescription>
              </CardHeader>
              <CardContent>
                {sessionLogs.length > 0 ? (
                  <div className="space-y-4">
                    {sessionLogs.map((log) => (
                      <div key={log.id} className="flex items-start gap-4 p-3 border-b last:border-0">
                        <div className="bg-security-100 p-2.5 rounded-full">
                          <History className="h-5 w-5 text-security-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <span className="font-medium">Login session</span>
                            <span className="text-sm text-gray-500">
                              {new Date(log.created_at).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">IP: {log.ip_address || 'Unknown'}</p>
                          <p className="text-sm text-gray-500">{log.user_agent || 'Unknown device'}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center py-4 text-gray-500">No recent activity to display</p>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="ghost" className="text-security-600 hover:text-security-700">
                  View all activity
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Account;
