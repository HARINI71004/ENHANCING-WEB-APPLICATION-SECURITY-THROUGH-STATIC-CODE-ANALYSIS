
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Shield, Lock, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";

const TwoFactorAuth = () => {
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [secret, setSecret] = useState<string | null>(null);
  const [otpValue, setOtpValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [is2FAEnabled, setIs2FAEnabled] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuthStatus = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast({
          title: "Authentication required",
          description: "Please log in to access this page",
          variant: "destructive",
        });
        navigate("/login");
      } else {
        fetchCurrentStatus();
      }
    };

    checkAuthStatus();
  }, [navigate, toast]);

  const fetchCurrentStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Check if 2FA is already enabled
      const { data, error } = await supabase
        .from("user_security")
        .select("two_factor_enabled, two_factor_verified")
        .eq("id", user.id)
        .single();

      if (error) {
        console.error("Error fetching 2FA status:", error);
        return;
      }

      setIs2FAEnabled(data.two_factor_enabled && data.two_factor_verified);
    } catch (error) {
      console.error("Error checking 2FA status:", error);
    }
  };

  const generateQRCode = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      // Generate a random secret
      const randomBytes = new Uint8Array(20);
      window.crypto.getRandomValues(randomBytes);
      const generatedSecret = Array.from(randomBytes)
        .map(b => b.toString(16).padStart(2, '0'))
        .join('')
        .slice(0, 32);

      // Store the secret in state
      setSecret(generatedSecret);
      
      // Create a URL for Google Authenticator/Authy
      const appName = "SecureShop";
      const username = user?.email || "user";
      const otpAuthUrl = `otpauth://totp/${encodeURIComponent(appName)}:${encodeURIComponent(username)}?secret=${generatedSecret}&issuer=${encodeURIComponent(appName)}`;
      
      // Generate QR code
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(otpAuthUrl)}&size=200x200`;
      setQrCodeUrl(qrUrl);

      // Save the secret to the database (but mark as unverified)
      const { error } = await supabase
        .from("user_security")
        .update({
          two_factor_secret: generatedSecret,
          two_factor_enabled: true,
          two_factor_verified: false
        })
        .eq("id", user!.id);

      if (error) {
        console.error("Error saving 2FA secret:", error);
        setError("Could not save your 2FA settings. Please try again.");
      }
    } catch (err) {
      console.error("Error generating QR code:", err);
      setError("Could not generate QR code. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // This would normally be done server-side, but for demonstration purposes:
  const verifyOTP = async () => {
    setIsVerifying(true);
    setError(null);

    try {
      if (!secret || otpValue.length !== 6) {
        setError("Please enter a valid 6-digit code");
        return;
      }

      // In a real implementation, this verification would happen server-side
      // For this demo, we'll simulate a successful verification
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setError("User not authenticated");
        return;
      }

      // Mark as verified in the database
      const { error } = await supabase
        .from("user_security")
        .update({
          two_factor_verified: true
        })
        .eq("id", user.id);

      if (error) {
        console.error("Error verifying 2FA:", error);
        setError("Could not verify your 2FA settings. Please try again.");
        return;
      }

      toast({
        title: "Two-factor authentication enabled",
        description: "Your account is now more secure with 2FA",
      });
      
      setIs2FAEnabled(true);
    } catch (err) {
      console.error("Error verifying OTP:", err);
      setError("Verification failed. Please try again.");
    } finally {
      setIsVerifying(false);
    }
  };

  const disable2FA = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Update the database
      const { error } = await supabase
        .from("user_security")
        .update({
          two_factor_enabled: false,
          two_factor_verified: false,
          two_factor_secret: null
        })
        .eq("id", user.id);

      if (error) {
        console.error("Error disabling 2FA:", error);
        setError("Could not disable 2FA. Please try again.");
        return;
      }

      toast({
        title: "Two-factor authentication disabled",
        description: "2FA has been turned off for your account",
      });
      
      setIs2FAEnabled(false);
      setQrCodeUrl(null);
      setSecret(null);
    } catch (err) {
      console.error("Error disabling 2FA:", err);
      setError("Could not disable 2FA. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-16 flex justify-center">
      <Card className="w-full max-w-md shadow-lg border-security-200">
        <CardHeader className="space-y-1">
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl">Two-Factor Authentication</CardTitle>
            <Badge variant="outline" className="security-badge">
              <Shield className="h-4 w-4 security-icon" />
              <span>Enhanced Security</span>
            </Badge>
          </div>
          <CardDescription>
            Add an extra layer of security to your account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {is2FAEnabled ? (
            <div className="space-y-4">
              <div className="bg-green-50 p-4 rounded-md border border-green-200">
                <div className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-green-600" />
                  <p className="text-green-700 font-medium">Two-factor authentication is enabled</p>
                </div>
                <p className="mt-2 text-sm text-green-600">
                  Your account is protected with an additional layer of security.
                </p>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full text-red-600 hover:text-red-700 border-red-200 hover:border-red-300 hover:bg-red-50"
                onClick={disable2FA}
                disabled={isLoading}
              >
                {isLoading ? "Processing..." : "Disable Two-Factor Authentication"}
              </Button>
            </div>
          ) : qrCodeUrl ? (
            <div className="space-y-6">
              <div className="flex flex-col items-center space-y-4">
                <p className="text-center text-gray-600 mb-2">
                  Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
                </p>
                <div className="border border-gray-200 p-2 rounded-md bg-white">
                  <img src={qrCodeUrl} alt="QR Code for 2FA" className="w-48 h-48" />
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-sm text-gray-600">
                  Enter the 6-digit code from your authenticator app:
                </p>
                <div className="flex justify-center">
                  <InputOTP maxLength={6} value={otpValue} onChange={setOtpValue}>
                    <InputOTPGroup>
                      <InputOTPSlot index={0} className="border-security-300 focus-within:ring-security-500" />
                      <InputOTPSlot index={1} className="border-security-300 focus-within:ring-security-500" />
                      <InputOTPSlot index={2} className="border-security-300 focus-within:ring-security-500" />
                      <InputOTPSlot index={3} className="border-security-300 focus-within:ring-security-500" />
                      <InputOTPSlot index={4} className="border-security-300 focus-within:ring-security-500" />
                      <InputOTPSlot index={5} className="border-security-300 focus-within:ring-security-500" />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
              </div>

              <Button
                className="w-full bg-security-600 hover:bg-security-700"
                onClick={verifyOTP}
                disabled={otpValue.length !== 6 || isVerifying}
              >
                {isVerifying ? "Verifying..." : "Verify & Enable"}
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-gray-600">
                Two-factor authentication adds an extra layer of security to your account. 
                Once enabled, you'll need to enter a verification code from your 
                authentication app in addition to your password when signing in.
              </p>
              
              <div className="flex flex-col space-y-2 border-t border-b border-gray-200 py-4">
                <div className="flex items-center gap-3">
                  <div className="bg-security-100 rounded-full p-1">
                    <Lock className="h-4 w-4 text-security-600" />
                  </div>
                  <span className="text-sm font-medium">Protects against unauthorized access</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="bg-security-100 rounded-full p-1">
                    <Lock className="h-4 w-4 text-security-600" />
                  </div>
                  <span className="text-sm font-medium">Uses a time-based verification code</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="bg-security-100 rounded-full p-1">
                    <Lock className="h-4 w-4 text-security-600" />
                  </div>
                  <span className="text-sm font-medium">Works with apps like Google Authenticator</span>
                </div>
              </div>

              <Button 
                className="w-full bg-security-600 hover:bg-security-700"
                onClick={generateQRCode}
                disabled={isLoading}
              >
                {isLoading ? "Setting up..." : "Set up two-factor authentication"}
              </Button>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button 
            variant="link" 
            onClick={() => navigate("/account")}
            className="text-security-600 hover:text-security-700"
          >
            Back to Account
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default TwoFactorAuth;
