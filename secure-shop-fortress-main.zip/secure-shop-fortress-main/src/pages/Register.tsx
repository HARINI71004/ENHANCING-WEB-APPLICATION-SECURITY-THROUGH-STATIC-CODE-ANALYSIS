
import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { User, Mail, Lock, Shield, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { supabase } from "@/integrations/supabase/client";
import { generateSalt, hashPassword } from "@/utils/passwordUtils";
import { sanitizeInput, generateCSRFToken, storeCSRFToken } from "@/utils/securityUtils";

const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [passwordStrength, setPasswordStrength] = useState<number>(0);
  const { toast } = useToast();
  const navigate = useNavigate();

  // Generate CSRF token on component mount
  useEffect(() => {
    const token = generateCSRFToken();
    storeCSRFToken(token);
  }, []);

  // Password strength checker
  useEffect(() => {
    if (!password) {
      setPasswordStrength(0);
      return;
    }
    
    let strength = 0;
    
    // Length check
    if (password.length >= 8) strength += 1;
    
    // Contains number
    if (/\d/.test(password)) strength += 1;
    
    // Contains special char
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength += 1;
    
    // Contains uppercase and lowercase
    if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength += 1;
    
    setPasswordStrength(strength);
  }, [password]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }
    
    if (passwordStrength < 3) {
      setError("Password is not strong enough. Please include uppercase letters, numbers, and special characters.");
      return;
    }
    
    setIsSubmitting(true);

    try {
      // Sanitize inputs
      const sanitizedName = sanitizeInput(name);
      const sanitizedEmail = sanitizeInput(email);
      
      // Generate salt and hash password using bcrypt
      const salt = generateSalt();
      const hashedPassword = await hashPassword(password, salt);

      // Register with Supabase
      const { data, error } = await supabase.auth.signUp({
        email: sanitizedEmail,
        password,
        options: {
          data: {
            full_name: sanitizedName,
          },
        },
      });

      if (error) {
        console.error("Registration error:", error);
        setError(error.message);
        return;
      }

      if (!data.user) {
        setError("Registration failed. Please try again.");
        return;
      }

      // Store password demo data
      const { error: demoError } = await supabase
        .from('password_demo')
        .insert({
          user_id: data.user.id,
          email: sanitizedEmail,
          original_password: password, // For demo only
          hashed_password: hashedPassword,
          salt: salt,
        });

      if (demoError) {
        console.error("Password demo storage error:", demoError);
        toast({
          title: "Demo Data Error",
          description: "There was an issue storing the password demo data.",
          variant: "destructive",
        });
      } else {
        console.log("Password demo data stored successfully");
      }

      // Check if email confirmation is required
      if (data.session === null) {
        toast({
          title: "Verification email sent",
          description: "Please check your email to confirm your account before logging in.",
        });
      } else {
        toast({
          title: "Registration successful",
          description: "Your account has been created. You can now log in.",
        });
      }

      navigate("/login");
    } catch (err) {
      console.error("Registration error:", err);
      setError("An unexpected error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Get strength color based on score
  const getStrengthColor = () => {
    switch (passwordStrength) {
      case 0: return "bg-gray-200";
      case 1: return "bg-red-500";
      case 2: return "bg-yellow-500";
      case 3: return "bg-green-400";
      case 4: return "bg-green-600";
      default: return "bg-gray-200";
    }
  };

  return (
    <div className="container mx-auto px-4 py-16 flex justify-center">
      <Card className="w-full max-w-md shadow-lg border-security-200">
        <CardHeader className="space-y-1">
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl">Create an account</CardTitle>
            <Badge variant="outline" className="security-badge">
              <Shield className="h-4 w-4 security-icon" />
              <span>Secured</span>
            </Badge>
          </div>
          <CardDescription>
            Enter your information to create a new account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <Input
                  id="name"
                  placeholder="John Doe"
                  className="pl-10"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  className="pl-10"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  className="pl-10"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={8}
                />
              </div>
              
              {/* Password strength indicator */}
              {password && (
                <div className="space-y-1">
                  <div className="h-1 flex rounded-full overflow-hidden">
                    <div className={`h-full w-1/4 ${passwordStrength >= 1 ? getStrengthColor() : 'bg-gray-200'}`}></div>
                    <div className={`h-full w-1/4 ${passwordStrength >= 2 ? getStrengthColor() : 'bg-gray-200'}`}></div>
                    <div className={`h-full w-1/4 ${passwordStrength >= 3 ? getStrengthColor() : 'bg-gray-200'}`}></div>
                    <div className={`h-full w-1/4 ${passwordStrength >= 4 ? getStrengthColor() : 'bg-gray-200'}`}></div>
                  </div>
                  <p className="text-xs text-gray-500">
                    {passwordStrength === 0 && "Enter a password"}
                    {passwordStrength === 1 && "Weak password"}
                    {passwordStrength === 2 && "Moderate password"}
                    {passwordStrength === 3 && "Good password"}
                    {passwordStrength === 4 && "Strong password"}
                  </p>
                </div>
              )}
              
              <p className="text-xs text-gray-500">
                Password must be at least 8 characters with uppercase, lowercase, numbers, and symbols
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-500" />
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  className="pl-10"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox id="terms" required />
              <Label htmlFor="terms" className="text-sm">
                I agree to the{" "}
                <Link
                  to="/terms"
                  className="text-security-600 hover:text-security-700"
                >
                  Terms of Service
                </Link>{" "}
                and{" "}
                <Link
                  to="/privacy"
                  className="text-security-600 hover:text-security-700"
                >
                  Privacy Policy
                </Link>
              </Label>
            </div>

            <Button
              type="submit"
              className="w-full bg-security-600 hover:bg-security-700"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Creating account..." : "Create Account"}
            </Button>
          </form>
        </CardContent>
        <CardFooter>
          <p className="text-center text-sm text-gray-600 w-full">
            Already have an account?{" "}
            <Link
              to="/login"
              className="text-security-600 hover:text-security-700 font-medium"
            >
              Log in
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Register;
