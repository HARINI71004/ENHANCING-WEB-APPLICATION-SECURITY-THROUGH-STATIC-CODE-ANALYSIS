
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldCheck, Lock, Key, Shield } from 'lucide-react';

const SecurityMeasure = ({ title, description, icon }: { title: string; description: string; icon: React.ReactNode }) => (
  <Card className="border-security-200 hover:border-security-300 transition-all">
    <CardHeader className="flex flex-row items-center gap-4 pb-2">
      <div className="bg-security-100 p-3 rounded-full">{icon}</div>
      <CardTitle>{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="text-gray-600">{description}</p>
    </CardContent>
  </Card>
);

const About = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto text-center mb-16">
        <h1 className="text-4xl font-bold mb-4">Our Security Approach</h1>
        <p className="text-lg text-gray-600">
          SecureShop is built with security as the top priority. Learn about the multiple layers of protection 
          we've implemented to keep your data and transactions safe.
        </p>
      </div>
      
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 mb-16">
        <SecurityMeasure
          title="Password Hashing"
          description="We use bcrypt, an industry-standard password hashing algorithm with appropriate salt rounds to securely store passwords. This ensures that even if data is compromised, passwords remain protected."
          icon={<Key className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="Two-Factor Authentication"
          description="Our 2FA implementation adds an additional verification step, requiring users to provide a second form of identification beyond just a password, significantly enhancing account security."
          icon={<Shield className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="SQL Injection Protection"
          description="We use prepared statements, parameterized queries, and input validation to prevent malicious SQL injection attacks that could compromise your data or the system."
          icon={<Shield className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="Cross-Site Scripting Protection"
          description="We implement content sanitization and encoding to prevent XSS attacks, ensuring that malicious scripts cannot be injected into our pages to steal data or hijack sessions."
          icon={<Shield className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="CSRF Protection"
          description="Our application implements anti-forgery tokens to prevent cross-site request forgery attacks, protecting users from having unauthorized commands executed from their authenticated browser."
          icon={<Shield className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="Secure Session Management"
          description="We implement secure, MySQL-backed sessions with appropriate timeouts and protection mechanisms to prevent session hijacking and ensure proper session termination."
          icon={<Lock className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="Secure Cookie Handling"
          description="All cookies are configured with HttpOnly, Secure, and SameSite flags where appropriate to protect against cookie theft and cross-site request attacks."
          icon={<Lock className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="Content Security Policy"
          description="Our CSP implementation restricts the sources from which content can be loaded, providing protection against various types of code injection attacks."
          icon={<Shield className="h-6 w-6 text-security-600" />}
        />
        
        <SecurityMeasure
          title="User Authentication"
          description="Our comprehensive authentication system includes secure login, registration, password recovery, and account management functionality with multiple security protections."
          icon={<Lock className="h-6 w-6 text-security-600" />}
        />
      </div>
      
      <div className="bg-security-50 rounded-lg p-8 border border-security-100 mb-16">
        <div className="flex items-center gap-3 mb-4">
          <ShieldCheck className="h-8 w-8 text-security-600" />
          <h2 className="text-2xl font-bold">Our Security Promise</h2>
        </div>
        <p className="text-gray-700">
          At SecureShop, security isn't just a feature—it's a core principle. We continuously update our security 
          measures to stay ahead of emerging threats and ensure your data remains protected. Every transaction, 
          login, and interaction with our platform is secured using industry best practices and modern security 
          techniques.
        </p>
      </div>
    </div>
  );
};

export default About;
